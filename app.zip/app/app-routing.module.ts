import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { ProductosSuperComponent } from './productos-super/productos-super.component';
import { DetalleComponentComponent } from './detalle-component/detalle-component.component';
import { CarritoComponent } from './carrito/carrito.component';
import { ConfirmarCompraComponent } from './confirmar-compra/confirmar-compra.component';
import { LoginComponent } from './login/login.component';
import { RegistroComponent } from './registro/registro.component';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';

const routes: Routes = [
  {path: '', component: LandingPageComponent },
  {path: 'inicio', component: LandingPageComponent },
  {path: 'productos/:tipo', component: ProductosSuperComponent},
  {path: 'detalle/:id', component: DetalleComponentComponent},
  {path: 'carrito', component: CarritoComponent},
  {path: 'confirmarCompra', component: ConfirmarCompraComponent},
  {path: 'login', component: LoginComponent},
  {path: 'registro', component: RegistroComponent},
  {path: 'admin', component: AdminPanelComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
