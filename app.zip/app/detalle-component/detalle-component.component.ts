import { Component, OnInit } from '@angular/core';
import { RecuperarProductosService } from '../servicios/recuperar-productos.service';
import { MainNavComponent } from '../main-nav/main-nav.component';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detalle-component',
  templateUrl: './detalle-component.component.html',
  styleUrls: ['./detalle-component.component.css']
})
export class DetalleComponentComponent implements OnInit {

// tslint:disable-next-line: max-line-length
  constructor(private productosServicio: RecuperarProductosService, private route: ActivatedRoute, private navComponent: MainNavComponent) { }
  public detalle = [];
  public productosCarrito = 0;
  precioSeleccionado = 0;
  ngOnInit() {
    this.route.paramMap.subscribe(params => {
// tslint:disable-next-line: radix
      let id = params.get('id');
      this.productosServicio.getDetalle(id).subscribe( ProductoDetalle => this.detalle = ProductoDetalle);
    });
  }

  seleccionarSupermercado(precio: number) {
    this.precioSeleccionado = precio;
  }
  comprarProducto(idProducto: string, foto: string, nombre: string ) {
    if (this.precioSeleccionado !== 0) {
      this.productosServicio.meterEnCarrito(idProducto, nombre, foto, this.precioSeleccionado, 1);
      this.navComponent.contadorCarrito();
    } else {
      alert("Debes seleccionar un supermercado para comprar el producto.");
    }
  }

}
