export class Item {
    idProduct: string;
    nombre: string;
    foto: string;
    precio: number;
    cantidad: number;
    subtotal: number;
    btnDisabled: boolean;
}
