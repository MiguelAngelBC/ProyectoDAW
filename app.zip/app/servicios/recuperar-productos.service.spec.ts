import { TestBed } from '@angular/core/testing';

import { RecuperarProductosService } from './recuperar-productos.service';

describe('RecuperarProductosService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RecuperarProductosService = TestBed.get(RecuperarProductosService);
    expect(service).toBeTruthy();
  });
});
