import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Producto } from '../producto';
import { ProductoDetalle } from '../productoDetalle';
import { Observable, of } from 'rxjs';
import { Item } from '../itemComprado';
@Injectable({
  providedIn: 'root'
})
export class RecuperarProductosService {
// https://ungorged-tissues.000webhostapp.com/php/filtrar.php?
  constructor(private http: HttpClient) {}
  private serviceUrl = 'https://ungorged-tissues.000webhostapp.com/php/filtrar.php?';
  private serviceUrlDetalle = 'https://ungorged-tissues.000webhostapp.com/php/detalle.php?';
  private servicioSesion = 'https://ungorged-tissues.000webhostapp.com/php/inicioSesion.php?';
  private servicioRegistro = 'https://ungorged-tissues.000webhostapp.com/php/registro.php?';

  getProducto( tipo: string): Observable<Producto[]> {
      return this.http.get<Producto[]>(this.serviceUrl, { params: new HttpParams().set('categoria', tipo) });
  }

  getDetalle(id: string): Observable<ProductoDetalle[]> {
    return this.http.get<ProductoDetalle[]>(this.serviceUrlDetalle, { params: new HttpParams().set('id', id )} );
  }

  meterEnCarrito(producto: string, nombreProd: string, fotoProd: string, precioProd: number, cantidadCompra: number) {
    let encontrado = false;
    let subtProd = precioProd * cantidadCompra;
    if (!localStorage.getItem('cart')) {
      localStorage.setItem('cart', '[]');
    }
    let carrito: Item[] = JSON.parse(localStorage.getItem('cart'));
// tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < carrito.length; i++) {
      if (carrito[i].idProduct === producto && carrito[i].precio === precioProd) {
        let cantidadTotal = carrito[i].cantidad + 1;
        carrito[i].cantidad++;
// tslint:disable-next-line: radix
        carrito[i].subtotal = carrito[i].precio * cantidadTotal;
        encontrado = true;
      }
    }
    if (encontrado === false ) {
// tslint:disable-next-line: max-line-length
      carrito.push({idProduct: producto, nombre: nombreProd, foto: fotoProd, precio: precioProd, cantidad: cantidadCompra, subtotal: subtProd, btnDisabled: true});
    }
    localStorage.setItem('cart', JSON.stringify(carrito));
  }

  contarProductosCarrito() {
    let cantidad = 0;
    let carrito: Item[] = JSON.parse(localStorage.getItem('cart'));
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < carrito.length; i++) {
        cantidad += carrito[i].cantidad;
    }
    return cantidad;
  }

  recuperarCarrito(): Observable<Item[]> {
    if (!localStorage.getItem('cart')) {
      localStorage.setItem('cart', '[]');
    }
    return of(JSON.parse(localStorage.getItem('cart')));
  }

  comprobarSesion(): Observable<any> {
    return this.http.get<any>(this.servicioSesion);
  }

  registro(post): Observable<any> {
// tslint:disable-next-line: max-line-length
    return this.http.post(this.servicioRegistro,  { params: new HttpParams().set('nombre', post.nombre).set('apellidos', post.apellidos).set('telf', post.telf).set('direc', post.direc).set('bday', post.bday).set('email', post.email).set('password', post.password)});
  }
}
