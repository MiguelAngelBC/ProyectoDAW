import { Component, OnInit } from '@angular/core';
import { RecuperarProductosService } from '../servicios/recuperar-productos.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-confirmar-compra',
  templateUrl: './confirmar-compra.component.html',
  styleUrls: ['./confirmar-compra.component.css']
})
export class ConfirmarCompraComponent implements OnInit {

  constructor(private productosServicio: RecuperarProductosService, private router: Router) { }

  ngOnInit() {
    this.productosServicio.comprobarSesion().subscribe(resultado => {
      if (resultado === 'iniciada') {
        alert('sesion iniciada');
      } else {
        this.router.navigate(['/login']);
      }
    });

  }
}
