import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RecuperarProductosService } from '../servicios/recuperar-productos.service';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {
  focusin = true;
  rForm: FormGroup;
  post: any;
  usernameAlert = 'Please fill username';
  constructor( private fb: FormBuilder, private productosServicio: RecuperarProductosService) {}

  ngOnInit() {
    this.rForm = this.fb.group({
      nombre : [null, [Validators.required, Validators.pattern('^[a-zA-Z]+$')]],
      apellidos : [null, [Validators.required, Validators.pattern('^[a-zA-Z]+$')]],
      telf : [null, [Validators.required, Validators.pattern('^[679]{1}[0-9]{8}$')]],
      direc : [null, Validators.required],
      bday : [null, Validators.required],
      email : [null, [Validators.required, Validators.pattern('^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$')]],
      //Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character
      password : [null, [Validators.required]],
    });
  }

  onSubmit() {
    if (this.rForm.valid) {
      alert('User form is valid!!');
      this.productosServicio.registro(this.rForm.value).subscribe((response) => {
        console.log('repsonse ', response); } );
    } else {
      alert('User form is not valid!!');
    }
  }

}
