import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductosSuperComponent } from './productos-super.component';

describe('ProductosSuperComponent', () => {
  let component: ProductosSuperComponent;
  let fixture: ComponentFixture<ProductosSuperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductosSuperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductosSuperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
