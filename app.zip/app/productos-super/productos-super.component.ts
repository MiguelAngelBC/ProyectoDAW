import { Component, OnInit } from '@angular/core';
import { RecuperarProductosService } from '../servicios/recuperar-productos.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-productos-super',
  templateUrl: './productos-super.component.html',
  styleUrls: ['./productos-super.component.css']
})
export class ProductosSuperComponent implements OnInit {

  constructor(private productosServicio: RecuperarProductosService, private route: ActivatedRoute) { }
  public listaProductos = [];
  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      let tipo = params.get('tipo');
      this.productosServicio.getProducto(tipo).subscribe( productos => this.listaProductos = productos);
    });
  }

}
