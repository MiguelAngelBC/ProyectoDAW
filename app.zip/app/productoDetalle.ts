export class ProductoDetalle {
    id: number;
    nombre: string;
    marca: string;
    descripcion: string;
    ingredientes: string;
    foto: string;
    alt: string;
    carrefour: number;
    dia: number;
    alcampo: number;
}
