import { Component, OnInit, ViewChild } from '@angular/core';
import { Item } from '../itemComprado';
import { RecuperarProductosService } from '../servicios/recuperar-productos.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { MainNavComponent } from '../main-nav/main-nav.component';

@Component({
  selector: 'app-carrito',
  templateUrl: './carrito.component.html',
  styleUrls: ['./carrito.component.css']
})
export class CarritoComponent implements OnInit {
  dataSource: any;
  displayedColumns = ['foto', 'nombre', 'precio', 'cantidad', 'customColumn1', 'subTotal'];
  public subtotal = 0;
  public total = 0;
  constructor(private productosServicio: RecuperarProductosService, private navComponent: MainNavComponent) { }

  ngOnInit() {
    this.cargarDatos();
  }

  cargarDatos() {
    this.productosServicio.recuperarCarrito().subscribe(items => {
      this.dataSource = new MatTableDataSource(items);
      this.dataSource.filterPredicate = (data: {nombre: string},
                                         filterValue: string) =>
          data.nombre.trim().toLowerCase().indexOf(filterValue) !== -1;
     });

    this.calcularTotal();
  }

  calcularTotal() {
    this.total = 0;
    const listaItems2: any = JSON.parse(localStorage.getItem('cart'));
// tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < listaItems2.length; i++) {
      const item: Item = listaItems2[i];
      this.total += item.precio * item.cantidad;
    }
    console.log(this.total);
  }
  remove(id: string): void {
    const listaItems: any = JSON.parse(localStorage.getItem('cart'));
    for (let i = 0; i < listaItems.length; i++) {
      const item: Item = listaItems[i];
      if (item.idProduct === id) {
        listaItems.splice(i, 1);
        break;
      }
    }
    localStorage.setItem('cart', JSON.stringify(listaItems));
    this.productosServicio.recuperarCarrito().subscribe(items => {
      this.dataSource = new MatTableDataSource(items);
      this.dataSource.filterPredicate = (data: {nombre: string},
                                         filterValue: string) =>
          data.nombre.trim().toLowerCase().indexOf(filterValue) !== -1;
    });
    this.calcularTotal();
    this.navComponent.contadorCarrito();
  }

  sumarCantidad(id: string) {
    const listaItems: any = JSON.parse(localStorage.getItem('cart'));
// tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < listaItems.length; i++) {
      const item: Item = listaItems[i];
      if (item.idProduct === id) {
        let cantidadTotal = item.cantidad + 1;
        item.cantidad++;
        item.btnDisabled = false;
// tslint:disable-next-line: radix
        item.subtotal = item.precio * cantidadTotal;
      }
    }
    localStorage.setItem('cart', JSON.stringify(listaItems));
    this.calcularTotal();
    this.cargarDatos();
    this.navComponent.contadorCarrito();
  }

  restarCantidad(id: string) {
    let cantidadTotal = 1;
    const listaItems: any = JSON.parse(localStorage.getItem('cart'));
// tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < listaItems.length; i++) {
      const item: Item = listaItems[i];
      if (item.idProduct === id) {
        if (item.cantidad > 1) {
          cantidadTotal = item.cantidad - 1;
          item.cantidad--;
          // tslint:disable-next-line: radix
          item.subtotal -= item.precio;
        } else {
          item.btnDisabled = true;
        }
      }
    }
    localStorage.setItem('cart', JSON.stringify(listaItems));
    this.calcularTotal();
    this.cargarDatos();
    this.navComponent.contadorCarrito();
  }
}
