export class Producto {
    id: number;
    nombre: string;
    foto: string;
    alt: string;
}
