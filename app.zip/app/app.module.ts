import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import 'hammerjs';
import { LayoutModule } from '@angular/cdk/layout';
import { MaterialModule } from './material-module';
import { MainNavComponent } from './main-nav/main-nav.component';
import { MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule } from '@angular/material';
import { NgMaterialMultilevelMenuModule } from 'ng-material-multilevel-menu';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { FooterComponent } from './footer/footer.component';
import { ProductosSuperComponent } from './productos-super/productos-super.component';
import { HttpClientModule } from '@angular/common/http';
import { DetalleComponentComponent } from './detalle-component/detalle-component.component';
import { CarritoComponent } from './carrito/carrito.component';
import { ConfirmarCompraComponent } from './confirmar-compra/confirmar-compra.component';
import { LoginComponent } from './login/login.component';
import { RegistroComponent } from './registro/registro.component';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';

@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    LandingPageComponent,
    FooterComponent,
    ProductosSuperComponent,
    DetalleComponentComponent,
    CarritoComponent,
    ConfirmarCompraComponent,
    LoginComponent,
    RegistroComponent,
    AdminPanelComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    LayoutModule,
    MaterialModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    NgMaterialMultilevelMenuModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
